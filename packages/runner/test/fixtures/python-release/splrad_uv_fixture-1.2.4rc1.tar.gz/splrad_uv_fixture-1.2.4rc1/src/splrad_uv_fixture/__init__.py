__version__ = "1.2.4rc1"
def answer():
    return 42
