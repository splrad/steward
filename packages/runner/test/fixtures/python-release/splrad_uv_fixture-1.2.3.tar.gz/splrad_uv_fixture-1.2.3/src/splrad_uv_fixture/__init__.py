__version__ = "1.2.3"
def answer():
    return 42
