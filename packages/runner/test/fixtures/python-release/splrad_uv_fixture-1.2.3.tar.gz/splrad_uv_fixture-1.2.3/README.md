# SPLRAD Python build fixture

Local acceptance sample.
